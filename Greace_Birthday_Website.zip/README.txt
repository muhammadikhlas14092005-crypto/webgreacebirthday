GREACE BIRTHDAY WEBSITE

1. Buka index.html untuk melihat website.
2. Untuk musik, tambahkan file audio yang kamu miliki/berhak gunakan ke:
   assets/perfect.mp3
3. Agar bisa dibagikan sebagai link, publikasikan folder ini pada layanan hosting/website builder.
4. Setelah URL publik sudah ada, QR Code final bisa dibuat agar mengarah ke URL tersebut.

Catatan: file lagu tidak disertakan.
